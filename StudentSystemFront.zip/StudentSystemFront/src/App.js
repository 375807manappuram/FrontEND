import './App.css';
import Navbar from './Components/Navbar';
import { Routes } from "react-router-dom";
import {Route} from "react-router-dom";
import Student from './Components/Student';
import Course from './Components/Course';
import Enrollment from './Components/Enrollment';

function App() {
  return (
   <>
   <Navbar/>
   <Routes>
<Route path='/addStudent' element= {<Student/>}></Route>
<Route path='/addCourse' element= {<Course/>}></Route>
<Route path='/addEnrollment' element= {<Enrollment/>}></Route>
</Routes>
   </>
  );
}

export default App;
