import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
const Course = () => {


        const [courses, setCourses] = useState([]);
    
        const [title, setNewCourseName] = useState('');

        const [description, setNewCourseDescription] = useState('');
    
        const [errorMessage, setErrorMessage] = useState('');
    
        const [successMessage, setSuccessMessage] = useState('');
    
    
    
        useEffect(() => {
    
            const fetchCourses = async () => {
    
                try {
    
                    const response = await fetch('https://localhost:7048/api/Course/GetCourses');
    
                    if (!response.ok) {
    
                        throw new Error('Failed to fetch courses');
    
                    }
    
                    const data = await response.json();
    
                    setCourses(data);
    
                } catch (error) {
    
                    setErrorMessage(error.message);
    
                }
    
            };
    
    
    
            fetchCourses();
    
        }, []);
    
    
    
        const handleAddCourse = async (e) => {
    
            e.preventDefault();
    
    
    
            if (!title) {
    
                setErrorMessage('Course name is required.');
    
                return;
    
            }
    
    
    
            const payload = { name: title,
                 description:description
             };
    
    
    
            try {
    
                const response = await fetch('http://localhost:5000/api/course/AddCourse', {
    
                    method: 'POST',
    
                    headers: {
    
                        'Content-Type': 'application/json',
    
                    },
    
                    body: JSON.stringify(payload),
    
                });
    
    
    
                if (!response.ok) {
    
                    throw new Error('Failed to add course');
    
                }
    
    
    
                const newCourse = await response.json();
    
                setCourses([...courses, newCourse]);
    
                setNewCourseName('');
    
                setSuccessMessage('Course added successfully!');
    
                setErrorMessage('');
    
            } catch (error) {
    
                setErrorMessage(error.message);
    
                setSuccessMessage('');
    
            }
    
        };
    
  return (
    <div>

    <h2>Course List</h2>



    {/* Display error or success messages */}

    {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}

    {successMessage && <p style={{ color: 'green' }}>{successMessage}</p>}



    {/* Form to add a new course */}

    <form onSubmit={handleAddCourse}>

        <input

            type="text"

            value={title}

            onChange={(e) => setNewCourseName(e.target.value)}

            placeholder="Enter course name"

            required

        />
        <br></br>
        <input

type="text"

value={description}

onChange={(e) => setNewCourseDescription(e.target.value)}

placeholder="Enter Course Description"

required

/>
<br></br>

        <button type="submit">Add Course</button>

    </form>



    {/* List of courses */}

    <ul>

        {courses.length > 0 ? (

            courses.map((course) => (

                <li key={course.id}> Course Name : {course.title}, Course Description: {course.description}</li>

            ))

        ) : (

            <p>No courses available.</p>

        )}

    </ul>

</div>
)
}

export default Course