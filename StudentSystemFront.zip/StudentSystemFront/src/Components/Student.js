import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';

const Student = () => {




        const [students, setStudents] = useState([]);

        const [name, setNewStudentName] = useState('');

       const [email, setNewStudentEmail] = useState('');

    
        const [errorMessage, setErrorMessage] = useState('');
    
        const [successMessage, setSuccessMessage] = useState('');
    
    
    
    
        useEffect(() => {
    
            const fetchStudents = async () => {
    
                try {
    
                    const response = await fetch('https://localhost:7048/api/Student/GetStudents');
    
                    if (!response.ok) {
    
                        throw new Error('Failed to fetch students');
    
                    }
    
                    const data = await response.json();
    
                    setStudents(data);
    
                } catch (error) {
    
                    setErrorMessage(error.message);
    
                }
    
            };
    
    
    
            fetchStudents();
    
        }, []);
    
    
    
    
        const handleAddStudent = async (e) => {
    
            e.preventDefault();
    
    
    
            if (!name) {
    
                setErrorMessage('Student name is required.');
    
                return;
    
            }
    
    
    
            const payload = { name: name,
                email:email
             };
    
    
    
            try {
    
                const response = await fetch('https://localhost:7048/api/Student/AddStudent', {
    
                    method: 'POST',
    
                    headers: {
    
                        'Content-Type': 'application/json',
    
                    },
    
                    body: JSON.stringify(payload),
    
                });
    
    
    
                if (!response.ok) {
    
                    throw new Error('Failed to add student');
    
                }
    
    
    
                const newStudent = await response.json();
    
                setStudents([...students, newStudent]);
    
                setNewStudentName('');
    
                setSuccessMessage('Student added successfully!');
    
                setErrorMessage('');
    
            } catch (error) {
    
                setErrorMessage(error.message);
    
                setSuccessMessage('');
    
            }
    
        };
    
    

        
  return (
<div>

<h2>Student List</h2>



{/* Display error or success messages */}

{errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}

{successMessage && <p style={{ color: 'green' }}>{successMessage}</p>}



{/* Form to add a new student */}

<form onSubmit={handleAddStudent}>

    <input

        type="text"

        value={name}

        onChange={(e) => setNewStudentName(e.target.value)}

        placeholder="Enter student name"

        required

    />
    <br></br>

<input

type="text"

value={email}

onChange={(e) => setNewStudentEmail(e.target.value)}

placeholder="Enter student email"

required

/>

<br></br>

    <button type="submit">Add Student</button>

</form>



{/* List of students */}

<ul>

    {students.length > 0 ? (

        students.map((student) => (

            <li key={student.id}>Student Name : {student.name}- Student Email : {student.email}</li>

        ))

    ) : (

        <p>No students available.</p>

    )}

</ul>

</div>

 )
}

export default Student