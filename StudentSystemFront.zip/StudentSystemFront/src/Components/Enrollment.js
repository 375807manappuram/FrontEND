import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';

const Enrollment = () => {

    const [students, setStudents] = useState([]);

    const [courses, setCourses] = useState([]);

    const [studentId, setSelectedStudentId] = useState('');

    const [courseId, setSelectedCourseId] = useState('');

    const [enrollmentMessage, setEnrollmentMessage] = useState('');

    const [errorMessage, setErrorMessage] = useState('');

    const [enrolledCourses, setEnrolledCourses] = useState([]);



    useEffect(() => {

        const fetchStudents = async () => {

            const response = await fetch('https://localhost:7048/api/Student/GetStudents');

            const data = await response.json();

            setStudents(data);

        };



        const fetchCourses = async () => {

            const response = await fetch('https://localhost:7048/api/Course/GetCourses');

            const data = await response.json();

            setCourses(data);

        };



        fetchStudents();

        fetchCourses();

    }, []);



    useEffect(() => {

        const fetchEnrolledCourses = async () => {

            if (studentId) {

                const response = await fetch(`https://localhost:7048/api/Enrollment/GetEnrollments/${studentId}`);

                const data = await response.json();

                setEnrolledCourses(data.map(enrollment => enrollment.title)); // Assuming enrollment has courseId

            }

        };



        fetchEnrolledCourses();

    }, [studentId]);



    const handleEnroll = async (e) => {

        e.preventDefault();



        const apiUrl = 'https://localhost:7048/api/Enrollment/AddEnrollments';



        const payload = {

            studentId: parseInt(studentId),

            courseId: parseInt(courseId),

        };



        try {

            const response = await fetch(apiUrl, {

                method: 'POST',

                headers: {

                    'Content-Type': 'application/json',

                },

                body: JSON.stringify(payload),

            });



            if (!response.ok) {

                throw new Error('Failed to enroll student in course');

            }



            const data = await response.json();

            setEnrollmentMessage(`Student successfully enrolled in course.`);

            setErrorMessage('');

        } catch (error) {

            setErrorMessage(`Error: ${error.message}`);

            setEnrollmentMessage('');

        }

    };

  return (
    <div>

    <h2>Enroll Student in Course</h2>



    {/* Dropdown for selecting student */}

    <div>

        <label>Select Student:</label>

        <select

            value={studentId}

            onChange={(e) => setSelectedStudentId(e.target.value)}

            required

        >

            <option value="">Select a student</option>

            {students.map((student) => (

                <option key={student.id} value={student.id}>{student.name}</option>

            ))}

        </select>

    </div>

    <br></br>


    {/* Dropdown for selecting course */}

    <div>

        <label>Select Course:</label>

        <select

            value={courseId}

            onChange={(e) => setSelectedCourseId(e.target.value)}

            required

        >

            <option value="">Select a course</option>

            {courses.map((course) => (

                <option key={course.id} value={course.id}>{course.title}</option>

            ))}

        </select>

    </div>

    <br></br>


    <button onClick={handleEnroll}>Enroll Student</button>



    {/* Enrollment messages */}

    {enrollmentMessage && <p>{enrollmentMessage}</p>}

    {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}



    {/* List of courses the selected student is enrolled in */}

    <h3>Enrolled Courses</h3>

    <ul>

        {enrolledCourses.length > 0 ? (

            enrolledCourses.map((courseId) => (

                <li key={courseId}>

                    {courses.find(course => course.id === courseId)?.title}

                </li>

            ))

        ) : (

            <p>No courses enrolled.</p>

        )}

    </ul>

</div>

)
}

export default Enrollment